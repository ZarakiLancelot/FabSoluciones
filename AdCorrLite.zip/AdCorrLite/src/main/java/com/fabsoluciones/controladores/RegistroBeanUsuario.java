package com.fabsoluciones.controladores;

import com.fabsoluciones.adcorrlite.Usuario;
import com.fabsoluciones.repositorios.UsuarioFacade;
import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

/**
 *
 * @author Desarrollo
 */
@Named(value = "registroBeanUsuario")
@RequestScoped
public class RegistroBeanUsuario {

    private String codUsuario;
    private String nomUsuario;
    private String clave;
    private String correoElectronico;
    
    @Inject
    private UsuarioFacade registrofacade;

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public String getNomUsuario() {
        return nomUsuario;
    }

    public void setNomUsuario(String nomUsuario) {
        this.nomUsuario = nomUsuario;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }
    
    /**
     * Creates a new instance of RegistroBeanUsuario
     */
    public RegistroBeanUsuario() {
    }
    
    public String guardar(){
        Usuario u = new Usuario();
        u.setNomUsuario(nomUsuario);
        u.setClave(clave);
        u.setCorreoElectronico(correoElectronico);
        u.setCodUsuario(codUsuario);
        this.registrofacade.create(u);
        //this.codUsuario = u.getCodUsuario();
        return "UsuariosLista";
    }
    
    public List<Usuario> getUsuarios(){
        return this.registrofacade.findAll();
    }
    
    public String prepareList(){
        return "UsuariosLista";
    }
    
    public String prepareCreate(){
        return "CrearUsuarios";
    }
    
    public String Eliminar(String codUsuario){
        Usuario u = this.registrofacade.find(codUsuario);
        this.registrofacade.remove(u);
        return "UsuariosLista";
    }
    
    public String Editar(String codUsuario){
        Usuario u = this.registrofacade.find(codUsuario);
        this.codUsuario = u.getCodUsuario();
        this.nomUsuario = u.getNomUsuario();
        this.clave = u.getClave();
        this.correoElectronico = u.getCorreoElectronico();
        return "UsuariosLista";
    }
    
    public String GuardarEdicion(RegistroBeanUsuario rbu, String codUsuario){
        Usuario u = new Usuario();
        u.setCodUsuario(rbu.codUsuario);
        u.setNomUsuario(rbu.nomUsuario);
        u.setClave(rbu.clave);
        u.setCorreoElectronico(rbu.correoElectronico);
        this.registrofacade.edit(u);
        return "UsuariosLista";
    }
    
}
